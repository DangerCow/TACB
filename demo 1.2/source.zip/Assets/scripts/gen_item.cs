﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gen_item : MonoBehaviour
{

    public string state = "placed";
    public string side_state = "none";

    private Vector3 mousePosition;
    public float z = -1;
    public float drag_speed = 0.07f;
    public float snap_dist = 0.6f;
    public string _snap;

    public GameObject[] mobo_snaps;

    public GameObject mobo_current_snap = null;
    public GameObject mobo = null;

    // Start is called before the first frame update
    void Start()
    {
        mobo_snaps = GameObject.FindGameObjectsWithTag(_snap);
    }

    // Update is called once per frame
    void Update()
    {
        mousePosition = Input.mousePosition;
        mousePosition = Camera.main.ScreenToWorldPoint(mousePosition);

        if (state == "picked up")
        {
            transform.position = Vector2.Lerp(transform.position, mousePosition, drag_speed);
        }

        if (state == "picked up")
        {
            side_state = "none";
        }

        foreach (GameObject snap in mobo_snaps)
        {
            float dist = Vector3.Distance(snap.transform.position, transform.position);
            print(dist);

            if (Input.GetMouseButton(1))
            {
                dist = 100;
            }

            if (dist < snap_dist && state == "picked up")
            {
                side_state = "on socket";
                mobo_current_snap = snap;
                mobo = snap.transform.parent.gameObject;
                transform.position = mobo_current_snap.transform.position;
            }
        }

        if (mobo_current_snap != null && side_state == "snaped on socket")
        {
            transform.position = mobo_current_snap.transform.position;
        }

        transform.position = new Vector3(transform.position.x, transform.position.y, z);

    }

    private void OnMouseDown()
    {
        if (state == "placed")
        {
            state = "picked up";
        }

        else if (state == "picked up")
        {
            state = "placed";
        }

        if (side_state == "on socket")
        {
            side_state = "snaped on socket";
            transform.parent = mobo.transform;
        }

        else if (side_state == "snaped on socket")
        {
            side_state = "on socket";
            mobo_current_snap = null;
            transform.parent = null;
        }
    }

    void OnCollisionEnter(Collision col)
    {

        print(col.gameObject.name);

    }
}
