﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mobo_item : MonoBehaviour
{

    private string state = "placed";
    private Vector3 mousePosition;

    public float z = 0;
    public float drag_speed = 0.07f;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        mousePosition = Input.mousePosition;
        mousePosition = Camera.main.ScreenToWorldPoint(mousePosition);

        if (state == "picked up")
        {
            transform.position = Vector2.Lerp(transform.position, mousePosition, drag_speed);
        }

        transform.position = new Vector3(transform.position.x, transform.position.y, z);
    }

    void OnMouseDown()
    {
        if (state == "placed")
        {
            state = "picked up";
        }

        else if (state == "picked up")
        {
            state = "placed";
        }
    }
}
